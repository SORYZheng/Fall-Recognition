import matplotlib.pyplot as plt
import numpy as np


def plot_confusion_matrix(cm, classes, savename):
    plt.figure(figsize=(12, 12), dpi=100)
    np.set_printoptions(precision=2)
    # 在混淆矩阵中每格的概率值
    ind_array = np.arange(len(classes))
    x, y = np.meshgrid(ind_array, ind_array)
    for x_val, y_val in zip(x.flatten(), y.flatten()):
        c = cm[y_val][x_val]
        if c > 0.001:
            plt.text(x_val, y_val, "%0.2f" % (c,), color='red', fontsize=18, va='center', ha='center')
    plt.imshow(cm, interpolation='none', cmap="Blues")
    # plt.colorbar()
    xlocations = np.array(range(len(classes)))
    plt.xticks(xlocations, classes, fontsize=24, family='Times New Roman', rotation='0')
    plt.yticks(xlocations, classes, fontsize=24, family='Times New Roman', rotation='0')
    plt.ylabel('Actual label', fontsize=24, family='Times New Roman')
    plt.xlabel('Predict label', fontsize=24, family='Times New Roman')
    # offset the tick
    tick_marks = np.array(range(len(classes))) + 0.5
    plt.gca().set_xticks(tick_marks, minor=True)
    plt.gca().set_yticks(tick_marks, minor=True)
    plt.gca().xaxis.set_ticks_position('none')
    plt.gca().yaxis.set_ticks_position('none')
    plt.grid(True, which='minor', linestyle='solid')
    plt.margins(2)
    # show confusion matrix
    plt.savefig('D:/PythonProject/LWDNN/dienet/98.26/C.tiff', bbox_inches='tight', dpi=330)
    plt.show()