import tensorflow as tf
import time
import numpy as np
from sklearn.metrics import confusion_matrix
from confusion_matrix import plot_confusion_matrix
from data import load_data
from keras.utils import plot_model
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

tf.random.set_seed(22)
np.random.seed(22)


start_time = time.time()

## preprocess
def preprocess(x, y):
    x = tf.io.read_file(x)
    x = tf.image.decode_jpeg(x, channels=3)  # RGBA
    x = tf.image.resize(x, [256, 256])
    x = tf.cast(x, dtype=tf.float32) / 255.
    y = tf.convert_to_tensor(y)
    y = tf.one_hot(y, depth=12)
    return x, y

## load data
images, labels, table = load_data('D:\data2\B-2')
db_test = tf.data.Dataset.from_tensor_slices((images, labels))
db_test = db_test.map(preprocess).batch(8)

## load LWCNN
model = tf.keras.models.load_model('LWCNN_97.67.h5')

## Evaluation
model.evaluate(db_test)
end_time = time.time()

print('运行时间:', end_time-start_time)


plot_model(model, to_file='LWDNN.png', show_shapes=True)

# classes
classes = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L']

# Confusion matrix
out = model.predict(db_test)
predict_labels = np.argmax(out, axis=1)
cm = confusion_matrix(labels, predict_labels)
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
plot_confusion_matrix(cm_normalized, classes, 'confusion_matrix.png')

