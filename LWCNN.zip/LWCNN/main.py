import tensorflow as tf
from calculations_parameters import try_count_flops, try_count_params
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
from confusion_matrix import plot_confusion_matrix
from data import load_data
import os
from keras.utils import plot_model
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

tf.random.set_seed(222)
np.random.seed(222)


def preprocess(x, y):
    x = tf.io.read_file(x)
    x = tf.io.decode_png(x, channels=3, dtype=tf.dtypes.uint8)  # RGBA
    x = tf.image.resize(x, [256, 256])
    x = tf.cast(x, dtype=tf.float32) / 255.
    y = tf.convert_to_tensor(y)
    y = tf.one_hot(y, depth=12)
    return x, y

batch_size=8
# create train db
images, labels, table = load_data('D:/data1', mode='train')
db_train = tf.data.Dataset.from_tensor_slices((images, labels))
db_train = db_train.shuffle(3000).map(preprocess).batch(batch_size)
# crate validation db
images2, labels2, table = load_data('D:/data1', mode='val')
db_val = tf.data.Dataset.from_tensor_slices((images2, labels2))
db_val = db_val.map(preprocess).batch(batch_size)
# create test db
images3, labels3, table = load_data('D:/data1', mode='test')
db_test = tf.data.Dataset.from_tensor_slices((images3, labels3))
db_test = db_test.map(preprocess).batch(batch_size)


def channel_shuffle(inputs, num_groups):
    n, h, w, c = inputs.shape
    x_reshaped = tf.reshape(inputs, [-1, h, w, num_groups, c // num_groups])
    x_transposed = tf.transpose(x_reshaped, [0, 1, 2, 4, 3])
    output = tf.reshape(x_transposed, [-1, h, w, c])
    return output


def conv(inputs, filters, kernel_size, strides=1):
    x = tf.keras.layers.Conv2D(filters, kernel_size, strides, padding='same')(inputs)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.activations.relu(x)

    return x


def GConv(x, Filters, groups, kernel, stride):
    """
        :param x: input tensor
        :param Filters: number of filters
        :param groups: number of groups
        :param kernel: kernel shape for group convolution operation
        :param stride: stride for group convolution operation
        :return: group convolution operation
    """
    channels = x.shape.as_list()[-1]
    channelsPerGroup = int(channels / groups)
    nbFiltersPerGroup = int(Filters / groups)

    F = tf.compat.v1.get_variable('kernel', [kernel, kernel, channelsPerGroup, Filters],
                                  tf.float32, tf.keras.initializers.glorot_normal())
    # split channels
    X_channel_splits = tf.split(x, [channelsPerGroup] * groups, axis=3)
    F_filter_splits = tf.split(F, [nbFiltersPerGroup] * groups, axis=3)

    results = []
    # do convolution for each split
    for i in range(groups):
        X_split = X_channel_splits[i]
        F_split = F_filter_splits[i]
        results += [tf.nn.conv2d(X_split, F_split, [1, stride, stride, 1], 'SAME')]
        y = tf.keras.layers.concatenate(results, 3)
    return y


def DieNetUnitA(inputs, out_channels, num_groups1):
    x = conv(inputs, out_channels//2, kernel_size=1, strides=1)
    x = GConv(x, Filters=out_channels//2, groups=num_groups1, kernel=3, stride=2)
    x = tf.keras.layers.BatchNormalization()(x)
    x = channel_shuffle(x, num_groups1)

    shortcut = GConv(inputs, Filters=out_channels, groups=num_groups1, kernel=5, stride=2)
    shortcut = tf.keras.layers.BatchNormalization()(shortcut)
    shortcut = channel_shuffle(shortcut, num_groups1)
    shortcut = conv(shortcut, out_channels, kernel_size=1, strides=1)

    output1 = tf.keras.layers.concatenate([shortcut, x], axis=-1)
    return output1


def DieNetUnitB(inputs, out_channels, num_groups2):
    shortcut, x1 = tf.split(inputs, 2, axis=-1)
    x = conv(inputs, out_channels//2, kernel_size=1, strides=1)
    x = GConv(x, Filters=out_channels//2, groups=num_groups2, kernel=5, stride=1)
    x = tf.keras.layers.BatchNormalization()(x)
    x = channel_shuffle(x, num_groups2)
    x = conv(x, out_channels // 2, kernel_size=1, strides=1)

    output2 = tf.keras.layers.concatenate([shortcut, x], axis=-1)
    output2 = channel_shuffle(output2, 2)
    return output2


def stage(x, out_channels, num_groups1, num_groups2):
    x = DieNetUnitA(x, out_channels, num_groups1)
    x = DieNetUnitB(x, out_channels, num_groups2)
    return x


def LWCNN(inputs, stage_channels):
    x = tf.keras.layers.Conv2D(filters=32, kernel_size=5, strides=2, padding='same')(inputs)
    x = tf.keras.activations.relu(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.MaxPooling2D(pool_size=5, strides=2, padding='same')(x)

    x = stage(x, out_channels=stage_channels * 2, num_groups1=8, num_groups2=8)
    x = tf.keras.layers.MaxPooling2D(pool_size=5, strides=1, padding='same')(x)
    x = stage(x, out_channels=stage_channels * 4, num_groups1=8, num_groups2=8)
    x = tf.keras.layers.MaxPooling2D(pool_size=3, strides=1, padding='same')(x)
    x = stage(x, out_channels=stage_channels * 8, num_groups1=16, num_groups2=16)
    x = tf.keras.layers.MaxPooling2D(pool_size=3, strides=1, padding='same')(x)
    x = tf.keras.layers.GlobalAveragePooling2D()(x)
    x = tf.keras.layers.Dense(12, activation='softmax')(x)
    return x


inputs = tf.keras.Input(shape=(256, 256, 3))
model = tf.keras.Model(inputs=inputs, outputs=LWCNN(inputs, 32))



model.summary()
model.compile(loss=tf.keras.losses.categorical_crossentropy,
              optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
              metrics=['Recall', 'AUC', 'accuracy'])

early_stopping = tf.keras.callbacks.EarlyStopping(monitor='val_loss',
                                                  min_delta=1e-5,
                                                  patience=10)
reduce_lr = tf.keras.callbacks.ReduceLROnPlateau(monitor='val_accuracy',
                                                 factor=0.5,
                                                 patience=2,
                                                 min_lr=1e-8,
                                                 verbose=1)
history = model.fit(db_train, batch_size=batch_size, epochs=200, callbacks=[early_stopping, reduce_lr], validation_data=db_val)

model.evaluate(db_test)

out = model.predict(db_test)
predict_labels = np.argmax(out, axis=1)
## confusion matrix
classes = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L']
cm = confusion_matrix(labels3, predict_labels)
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
plot_confusion_matrix(cm_normalized, classes, 'confusion_matrix.png')

## count_params and flops
params = try_count_params(model)
flops = try_count_flops(model)
print('params', params, 'flops', flops)

## save model
model.save('LWCNN_a.h5')
plot_model(model, to_file='LWCNN.png', show_shapes=True)

## accuracy
plt.figure()
plt.plot(history.history["accuracy"])
plt.plot(history.history["val_accuracy"])
plt.legend(['training', 'validation'], loc='lower right', fontsize=12, frameon=True)
plt.xlabel("Epoch", fontsize=14, family='Times New Roman')
plt.ylabel("Accuracy", fontsize=14, family='Times New Roman')
plt.xticks(fontsize=14, family='Times New Roman')
plt.yticks(fontsize=14, family='Times New Roman')

# loss
plt.figure()
plt.plot(history.history["loss"])
plt.plot(history.history["val_loss"])
plt.legend(['training', 'validation'], loc='upper right', fontsize=12, frameon=True)
plt.xlabel("Epoch", fontsize=14, family='Times New Roman')
plt.ylabel("Loss", fontsize=14, family='Times New Roman')
plt.xticks(fontsize=14, family='Times New Roman')
plt.yticks(fontsize=14, family='Times New Roman')
plt.show()
